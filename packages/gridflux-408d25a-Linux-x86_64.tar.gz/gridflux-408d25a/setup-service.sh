#!/bin/bash
set -e
INSTALL_DIR="/usr/local/bin"
SERVICE_FILE="$HOME/.config/systemd/user/gridflux.service"

echo "Setting up GridFlux service..."

# Create systemd service
mkdir -p "$(dirname "$SERVICE_FILE")"
cat > "$SERVICE_FILE" << 'EOL'
[Unit]
Description=GridFlux Window Tiler
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
ExecStart=$INSTALL_DIR/gridflux
Restart=on-failure
RestartSec=5

[Install]
WantedBy=graphical-session.target
EOL

# Enable and start service
systemctl --user daemon-reload
systemctl --user enable gridflux.service
systemctl --user start gridflux

echo "✓ GridFlux service is now running!"
echo "Check status: systemctl --user status gridflux"
